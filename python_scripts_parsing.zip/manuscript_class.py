from manuscript import Manuscript

manuscript = Manuscript("./Stitny_Reci-nedelni.txt", "Řeči nedělní", "Tomáš Štítný ze Štítného")
manuscript.find_form("jest")