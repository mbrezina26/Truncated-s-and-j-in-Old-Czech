class PrintsCollection: # třída na vytvoření zpracovaného souboru, odpovídá už zpracované kolekci
	
	def __init__(self, prints):
		self.prints = prints # celý rozparserovaný soubor

	def __str__(self): # říká, jak bude vypadat výstup
		final_string = ""
		for key in self.prints.keys():
			final_string += key + ": " + str(self.prints[key])
		return final_string

	def find_letter(self, letter):
		result = []
		for print_id in self.prints.keys():
			result += self.find_letter_in_print(self.prints[print_id], letter, print_id)
		return result #[{print_id, page_id, word}] 


	def find_letter_in_print(self, selected_print, letter, print_id):
		result = []
		for page in range(len(selected_print)):
			page_id = self.calculate_page_id(page)
			result += self.find_letter_in_page(selected_print[page]), letter, print_id, page_id
		return result #[{print_id, page_id, word}]

	def find_letter_in_page(self, selected_page, letter, print_id, page_id):
		result = []
		words = self.split_to_words(selected_page)
		result = self.find_letter_in_words(words, letter, print_id, page_id)
		return result #[{print_id, page_id, word}]

	def calculate_page_id(self, page_index):
		page_id = str((page_index//2)+1) + self.recto_verso(page_index)
		return page_id

	def recto_verso(self, page_index):
		if page_index%2 == 0:
			return "r"
		else:
			return "v"
		
	def split_to_words(self, selected_page):
		return selected_page.split(" ")

	def find_letter_in_words(self, words, letter, print_id, page_id):
		result = []
		for word in words:
			if letter in word:
				result.append({
					"word": word,
					"print_id": print_id,
					"page_id": page_id
				})
		return result #[{print_id, page_id, word}]
		
				