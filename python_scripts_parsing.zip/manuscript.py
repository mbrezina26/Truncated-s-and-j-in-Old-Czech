class Manuscript:

	def __init__(self, filename, name, author):
		self.name = name
		self.author = author
		self.text = ""
		self.length = 0
		self.pages = []
		self.load_text(filename)
		self.sentences = self.parse_sentences()


	def load_text(self,filename):
		with open(filename, 'r') as f:
			lines = f.readlines()
			for i in range(len(lines)):
				if self.checkIfText(lines, i):
					if lines[i].startswith("["):
						pageId = lines[i].split("]")[0].replace("[", "")
						line = lines[i].replace("["+pageId+"]"," ").replace("\n"," ")
						self.pages.append({"pageId":pageId, "start":self.length, "end": self.length + len(line)})
						self.text += line
						self.length += len(line)
					else:
						self.text += " " + lines[i].replace("\n"," ")
						self.length += len(lines[i]) + 1
						self.pages[-1]["end"] = self.length - 1



	
	
	
	def checkIfText(self, lines, i): 
		if not self.checkIfNote(lines, i) and (not self.checkIfNote(lines, i - 1) or lines[i].strip(" ").startswith("[")) :   
			return True
		return False
		
	def checkIfNote(self, lines, i):
		if len(lines[i].strip(" ")) <= 4 and not lines[i].strip(" ")										.endswith(".") and not lines[i].strip(" ").endswith("!") and not lines[i].strip(" ").endswith("?"):
			return True
		return False

	def parse_sentences(self):
		return self.text.split(".")

	def find_form(self, form):
		list_of_sentences = []
		position = 0
		for sentence in self.sentences:
			if form in sentence:
				list_of_sentences.append(sentence)
				print(sentence + "(" + str(self.find_pages(position, position + len(sentence))) + ")")
				print()
				position += len(sentence)
		return list_of_sentences

	def find_pages(self, start, end):
		included_pages = []
		for page in self.pages:
			if page["start"] < end and page["end"] > start:
				included_pages.append(page["pageId"])
		return included_pages
			
			