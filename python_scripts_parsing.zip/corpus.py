class Token:

  def __init__(self, form, lemma, tag = None):
    self.form = form
    self.lemma = lemma
    self.tag = tag

  def __str__(self):
    return self.form + "/" + self.lemma + "/" + self.tag

class Corpus:

  def __init__(self, tokens):
    self.tokens = tokens

  def frequencies(self):
    frequencies = {}
    for token in self.tokens:
      if token.form not in frequencies.keys():
        frequencies[token.form] = 1
      else:
        frequencies[token.form] = frequencies[token.form] + 1
    return frequencies

  def lemma_frequencies(self):
    frequencies = {}
    for token in self.tokens:
      if token.lemma not in frequencies.keys():
        frequencies[token.lemma] = 1
      else:
        frequencies[token.lemma] = frequencies[token.lemma] + 1
    return frequencies