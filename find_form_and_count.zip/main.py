from corpus import Token, Corpus
#from text_parser import Parser
import re

with open("Stitny_Reci-nedelni.txt", "r") as text:
	
	sentences = text.readlines()
	
	form = input("What form do you wish to find? ")
	print("\n")
	forms = 0
	
	for sentence in sentences:
		if form in sentence:
			forms = forms + 1
			print(str(forms) + " occurance: " + sentence)

	print("\nYour form \"" + form + "\" was found " + str(forms) + " times.")

	text.close()