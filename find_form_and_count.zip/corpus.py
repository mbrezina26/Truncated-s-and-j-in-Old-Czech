class Token:

	def __init__(self, form, lemma = None, tag = None):
		self.form = form
		self.lemma = lemma
		self.tag = tag

'''	def __tokenize(self, list)
		for word in list:
			Token(word)
'''
	

class Corpus:

	def __init__(self, tokens):
		self.tokens = tokens

	def form_counter(self):
		form_counter = {}
		for token in self.tokens:
			if token.form not in form_counter.keys():
				form_counter[token.form] = 1
			else:
				form_counter[token.form] = form_counter[token.form] + 1
		return form_counter

	def lemma_counter(self):
		lemma_counter = {}
		for token in self.tokens:
			if token.lemma not in lemma_counter.keys():
				lemma_counter[token.lemma] = 1
			else:
				lemma_counter[token.lemma] = lemma_counter[token.lemma] + 1
		return lemma_counter

	def tag_counter(self):
		tag_counter = {}
		for token in self.tokens:
			if token.tag not in tag_counter.keys():
				tag_counter[token.tag] = 1
			else:
				tag_counter[token.tag] = tag_counter[token.tag] + 1
		return tag_counter
		