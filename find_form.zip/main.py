import re

from manuscript import Manuscript

manuscript = Manuscript("./Stitny_Reci-nedelni.txt", "Řeči nedělní", "Tomáš Štítný ze Štítného")

form_to_find = input("What form do you wish to find? ")
manuscript.find_form(form_to_find)